/**
 * Crop Health — ML model status and future vision service placeholder.
 * Honest about what is and isn't available yet.
 */
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '../api/client';
import { ConditionCard } from '../components/ui/ConditionCard';
import type { FieldConditionSummary } from '../types';

const FIELD_ID = 'field-north-01';

export default function CropHealth() {
  const { data: condition } = useQuery<FieldConditionSummary>({
    queryKey: ['field-condition', FIELD_ID],
    queryFn: () => api.fields.condition(FIELD_ID),
    refetchInterval: 15000,
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-6)', maxWidth: 800 }}>
      <div>
        <h1 style={{ fontSize: 'var(--text-2xl)', marginBottom: 4 }}>Crop Health</h1>
        <p style={{ color: 'var(--color-text-muted)', fontSize: 'var(--text-sm)' }}>
          Sensor-based crop stress indicators and ML model status.
        </p>
      </div>

      {/* Sensor-based stress summary */}
      {condition && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
          <ConditionCard
            title="Water Stress Level"
            severity={condition.water_stress_level}
            explanation={condition.water_stress_level !== 'none'
              ? `Soil moisture and environmental conditions indicate ${condition.water_stress_level} water stress. Timely irrigation can prevent crop damage.`
              : 'Soil moisture is adequate. No water stress detected.'}
            recommendedAction={condition.water_stress_level === 'critical' ? 'Irrigate immediately.' : undefined}
            icon="💧"
          />
          <ConditionCard
            title="Heat Stress Level"
            severity={condition.heat_stress_level}
            explanation={condition.heat_stress_level !== 'none'
              ? `Temperature conditions are placing stress on the crop canopy. Combined with water stress, this can rapidly damage the crop.`
              : 'Temperature is within the acceptable range.'}
            icon="🌡"
          />
        </div>
      )}

      {/* ML Architecture section */}
      <div className="card" style={{ borderColor: 'var(--color-status-info-border)', background: 'var(--color-status-info-bg)' }}>
        <div style={{ fontWeight: 700, fontSize: 'var(--text-base)', color: 'var(--color-status-info)', marginBottom: 'var(--space-3)' }}>
          ML & Computer Vision — Architecture Ready
        </div>
        <p style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--text-sm)', lineHeight: 1.6, marginBottom: 'var(--space-4)' }}>
          The backend ML registry is fully operational. Models are registered as plug-ins —
          adding a trained model requires no application code changes.
        </p>

        {/* Model status table */}
        <div className="table-container">
          <table className="table" style={{ background: 'var(--color-surface-2)', borderRadius: 'var(--radius-md)', overflow: 'hidden' }}>
            <thead>
              <tr>
                <th>Model</th>
                <th>Type</th>
                <th>Status</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              <ModelRow name="Irrigation Predictor" type="irrigation" status="stub" notes="Will use time-series features from TimescaleDB" />
              <ModelRow name="Crop Stress Predictor" type="stress" status="stub" notes="Multi-sensor input, classification output" />
              <ModelRow name="Vision — Disease/Pest Detection" type="disease" status="pending_hardware" notes="Requires camera hardware (Raspberry Pi or Jetson Nano)" />
            </tbody>
          </table>
        </div>

        <div style={{ marginTop: 'var(--space-4)', fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
          <strong>To add a real model:</strong> Implement <code>MLModel</code> base class in{' '}
          <code>backend/app/ml/</code>, register it in <code>registry.py</code>.
          All historical data is stored in TimescaleDB and available for training.
        </div>
      </div>

      {/* Vision service section */}
      <div className="card">
        <div style={{ fontWeight: 600, fontSize: 'var(--text-base)', marginBottom: 'var(--space-3)' }}>
          ML Vision Diagnostics
        </div>
        
        <VisionUploader />
        
      </div>
    </div>
  );
}

function VisionUploader() {
  const [file, setFile] = React.useState<File | null>(null);
  const [preview, setPreview] = React.useState<string | null>(null);
  const [isUploading, setIsUploading] = React.useState(false);
  const [result, setResult] = React.useState<any>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      setFile(selected);
      setPreview(URL.createObjectURL(selected));
      setResult(null); // Clear previous result
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setIsUploading(true);
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      // Direct fetch to backend since this is a new endpoint
      const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
      const response = await fetch(`${API_URL}/api/v1/vision/detect`, {
        method: 'POST',
        body: formData,
      });
      
      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error("Upload failed", err);
      alert("Failed to reach ML Vision service");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
      {!preview ? (
        <label style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 'var(--space-4)',
          padding: 'var(--space-8)',
          background: 'var(--color-surface-2)',
          borderRadius: 'var(--radius-md)',
          border: '2px dashed var(--color-border)',
          cursor: 'pointer',
        }}>
          <div style={{ fontSize: '2.5rem' }}>📷</div>
          <div style={{ fontWeight: 600, color: 'var(--color-text-secondary)' }}>Take Photo or Upload Image</div>
          <div style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-muted)', textAlign: 'center' }}>
            Upload a photo of a leaf or crop to run ML disease & pest detection.
          </div>
          <input type="file" accept="image/*" onChange={handleFileChange} style={{ display: 'none' }} />
        </label>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
          <div style={{ display: 'flex', gap: 'var(--space-4)' }}>
            <img src={preview} alt="Crop preview" style={{ width: 120, height: 120, objectFit: 'cover', borderRadius: 'var(--radius-md)' }} />
            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 'var(--space-2)' }}>
              <div style={{ fontWeight: 600, color: 'var(--color-text-secondary)' }}>{file?.name}</div>
              <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
                <button className="btn btn-primary" onClick={handleUpload} disabled={isUploading}>
                  {isUploading ? 'Analyzing Model...' : 'Run ML Detection'}
                </button>
                <button className="btn" onClick={() => { setFile(null); setPreview(null); setResult(null); }} disabled={isUploading}>
                  Cancel
                </button>
              </div>
            </div>
          </div>
          
          {result && (
            <div style={{
              marginTop: 'var(--space-2)', padding: 'var(--space-4)', 
              borderRadius: 'var(--radius-md)', 
              border: `1px solid ${result.disease_detected ? 'var(--color-status-critical)' : 'var(--color-status-normal)'}`,
              background: 'var(--color-surface-2)'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 'var(--space-2)' }}>
                <div style={{ fontWeight: 600, fontSize: 'var(--text-lg)', color: result.disease_detected ? 'var(--color-status-critical)' : 'var(--color-status-normal)' }}>
                  {result.prediction}
                </div>
                <div className="badge badge-normal">
                  {(result.confidence * 100).toFixed(1)}% Confidence
                </div>
              </div>
              <p style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>
                {result.recommendation}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ModelRow({ name, type, status, notes }: {
  name: string; type: string; status: string; notes: string;
}) {
  return (
    <tr>
      <td style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)' }}>{name}</td>
      <td><code style={{ fontSize: 'var(--text-xs)', color: 'var(--color-text-muted)' }}>{type}</code></td>
      <td>
        <span className={`badge ${status === 'active' ? 'badge-normal' : status === 'stub' ? 'badge-monitor' : 'badge-offline'}`}>
          {status === 'stub' ? 'Stub — awaiting model' : status === 'pending_hardware' ? 'Pending hardware' : 'Active'}
        </span>
      </td>
      <td style={{ color: 'var(--color-text-muted)', fontSize: 'var(--text-xs)' }}>{notes}</td>
    </tr>
  );
}

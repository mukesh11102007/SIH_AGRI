/**
 * Dashboard — "How is my farm doing right now?"
 *
 * Answers these questions within seconds of loading:
 * 1. Is irrigation needed?
 * 2. Is there any active stress?
 * 3. Is water available?
 * 4. Are there active alerts?
 * 5. What are the current conditions?
 */
import React, { useState, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { formatDistanceToNow, parseISO } from 'date-fns';
import { api } from '../api/client';
import { useRealtimeUpdates } from '../api/useRealtimeUpdates';
import { StatusBadge, StatusDot } from '../components/ui/StatusBadge';
import { ConditionCard } from '../components/ui/ConditionCard';
import { MetricTile, SensorValue } from '../components/ui/SensorValue';
import type { FieldConditionSummary, WebSocketMessage } from '../types';

const FARM_ID = 'farm-001';
const FIELD_ID = 'field-north-01';

const IRRIGATION_LABELS: Record<string, string> = {
  NORMAL: 'Irrigation not required.',
  MONITOR: 'Monitor soil moisture closely.',
  IRRIGATION_RECOMMENDED: 'Irrigation is recommended now.',
  IRRIGATION_BLOCKED: 'Irrigation blocked — water unavailable.',
  EXCESS_MOISTURE: 'Too wet — do not irrigate.',
};

const IRRIGATION_ACTIONS: Record<string, string | null> = {
  NORMAL: null,
  MONITOR: 'Check soil moisture again in 1–2 hours.',
  IRRIGATION_RECOMMENDED: 'Irrigate the field as soon as possible.',
  IRRIGATION_BLOCKED: 'Refill the water tank or check the supply line.',
  EXCESS_MOISTURE: 'Check drainage. Avoid any additional irrigation.',
};

export default function Dashboard() {
  const queryClient = useQueryClient();
  const [lastUpdate, setLastUpdate] = useState<string | null>(null);

  const { data: summary, isLoading, error } = useQuery<FieldConditionSummary>({
    queryKey: ['field-condition', FIELD_ID],
    queryFn: () => api.fields.condition(FIELD_ID),
    refetchInterval: 30000,
  });

  const { data: alerts } = useQuery({
    queryKey: ['alerts-active', FARM_ID],
    queryFn: () => api.farms.alerts(FARM_ID, 'active'),
    refetchInterval: 30000,
  });

  // Real-time updates
  useRealtimeUpdates({
    farmId: FARM_ID,
    onMessage: useCallback((msg: WebSocketMessage) => {
      if (msg.event === 'sensor_update') {
        setLastUpdate(new Date().toISOString());
        queryClient.setQueryData(['field-condition', FIELD_ID], (old: any) => ({
          ...old,
          irrigation_status: msg.irrigation_status ?? old?.irrigation_status,
          irrigation_severity: msg.irrigation_severity ?? old?.irrigation_severity,
          air_temperature_c: msg.air_temperature_c ?? old?.air_temperature_c,
          air_humidity_pct: msg.air_humidity_pct ?? old?.air_humidity_pct,
          soil_moisture_pct: msg.soil_moisture_pct ?? old?.soil_moisture_pct,
        }));
        // Still invalidate alerts since they aren't part of the basic payload
        queryClient.invalidateQueries({ queryKey: ['alerts-active'] });
      }
    }, [queryClient]),
  });

  if (isLoading) return <DashboardSkeleton />;
  if (error) return <ErrorState message="Unable to load farm data. Check backend connection." />;
  if (!summary) return null;

  const irrigationSeverity = summary.irrigation_status === 'IRRIGATION_RECOMMENDED' ? 'critical'
    : summary.irrigation_status === 'IRRIGATION_BLOCKED' ? 'high'
    : summary.irrigation_status === 'MONITOR' ? 'medium'
    : summary.irrigation_status === 'EXCESS_MOISTURE' ? 'medium' : 'none';

  const topStress = [
    { label: 'Water Stress', sev: summary.water_stress_level },
    { label: 'Heat Stress', sev: summary.heat_stress_level },
    { label: 'Excess Moisture', sev: summary.excess_moisture_level },
  ].filter(s => s.sev !== 'none');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-6)', maxWidth: 'var(--content-max-w)' }}>

      {/* ── Page header ─────────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 'var(--space-3)' }}>
        <div>
          <h1 style={{ fontSize: 'var(--text-2xl)', marginBottom: 2 }}>Farm Overview</h1>
          <div style={{ color: 'var(--color-text-muted)', fontSize: 'var(--text-sm)', display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}>
            <StatusDot status={summary.device_status} />
            <span>
              {summary.field_name}
              {summary.crop_name ? ` · ${summary.crop_name}` : ''}
              {summary.growth_stage ? ` · ${summary.growth_stage}` : ''}
            </span>
            {lastUpdate && (
              <span>· Updated {formatDistanceToNow(new Date(lastUpdate))} ago</span>
            )}
          </div>
        </div>
        <StatusBadge status={summary.device_status} />
      </div>

      {/* ── Critical alerts banner ───────────────────────────── */}
      {alerts && alerts.filter(a => a.severity === 'critical').map(alert => (
        <div key={alert.id} className="alert-banner alert-banner-critical">
          <span style={{ fontSize: '1.2rem', flexShrink: 0, marginTop: 1 }}>⚠</span>
          <div>
            <div style={{ fontWeight: 'var(--font-semibold)', color: 'var(--color-status-critical)', marginBottom: 4 }}>
              {alert.title}
            </div>
            <div style={{ color: 'var(--color-text-secondary)', fontSize: 'var(--text-sm)' }}>
              {alert.explanation}
            </div>
            {alert.recommended_action && (
              <div style={{ color: 'var(--color-text-muted)', fontSize: 'var(--text-xs)', marginTop: 'var(--space-2)' }}>
                Action: {alert.recommended_action}
              </div>
            )}
          </div>
        </div>
      ))}

      {/* ── Irrigation status — PRIMARY card ─────────────────── */}
      <ConditionCard
        title="Irrigation Status"
        severity={irrigationSeverity}
        explanation={summary.irrigation_reasoning}
        recommendedAction={IRRIGATION_ACTIONS[summary.irrigation_status] ?? undefined}
        icon={summary.irrigation_status === 'IRRIGATION_RECOMMENDED' ? '💧' : '🌱'}
      />

      {/* ── Key metrics ─────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 'var(--space-4)' }}>
        <MetricTile
          label="Soil Moisture"
          value={summary.soil_moisture_pct?.toFixed(1) ?? null}
          unit="%"
          color={summary.water_stress_level !== 'none' ? 'var(--color-status-warning)' : undefined}
        />
        <MetricTile
          label="Air Temperature"
          value={summary.air_temperature_c?.toFixed(1) ?? null}
          unit="°C"
          color={summary.heat_stress_level !== 'none' ? 'var(--color-status-warning)' : undefined}
        />
        <MetricTile
          label="Air Humidity"
          value={summary.air_humidity_pct?.toFixed(0) ?? null}
          unit="%"
        />
        <MetricTile
          label="Water Source"
          value={summary.water_availability === 'available' ? 'OK' : 'Check'}
          color={summary.water_availability !== 'available' ? 'var(--color-status-critical)' : 'var(--color-status-normal)'}
        />
      </div>

      {/* ── Stress conditions + Sensor details ──────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 'var(--space-4)' }}>

        {/* Stress conditions */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
          <h2 style={{ fontSize: 'var(--text-base)', fontWeight: 'var(--font-semibold)', color: 'var(--color-text-secondary)', letterSpacing: '0.03em' }}>
            FIELD CONDITIONS
          </h2>
          {topStress.length === 0 ? (
            <div className="card" style={{ color: 'var(--color-status-normal)', fontSize: 'var(--text-sm)', display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}>
              <span>✓</span> All conditions are within normal range.
            </div>
          ) : (
            topStress.map(s => (
              <ConditionCard
                key={s.label}
                title={s.label}
                severity={s.sev}
                explanation={`${s.label} level is ${s.sev}.`}
                compact
              />
            ))
          )}

          {/* Activity signal */}
          {summary.activity_signal === 'elevated' && (
            <ConditionCard
              title="Activity Signal"
              severity="low"
              explanation="The vibration sensor detected elevated field activity. Physical inspection recommended. This signal does not identify a specific cause."
              recommendedAction="Conduct a field inspection."
              compact
            />
          )}

          {/* Active alerts count */}
          {summary.active_alert_count > 0 && (
            <div className="card" style={{ borderLeftColor: 'var(--color-status-warning)', borderLeftWidth: 3, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-secondary)' }}>
                Active Alerts
              </span>
              <span className="badge badge-warning">{summary.active_alert_count}</span>
            </div>
          )}
        </div>

        {/* Current sensor readings */}
        <div>
          <h2 style={{ fontSize: 'var(--text-base)', fontWeight: 'var(--font-semibold)', color: 'var(--color-text-secondary)', letterSpacing: '0.03em', marginBottom: 'var(--space-3)' }}>
            CURRENT READINGS
          </h2>
          <div className="card" style={{ padding: 'var(--space-4)' }}>
            <SensorValue label="Air Temperature" value={summary.air_temperature_c} unit="°C" />
            <div className="divider" style={{ margin: 'var(--space-1) 0' }} />
            <SensorValue label="Air Humidity" value={summary.air_humidity_pct} unit="%" />
            <div className="divider" style={{ margin: 'var(--space-1) 0' }} />
            <SensorValue label="Soil Moisture" value={summary.soil_moisture_pct} unit="%" />
            <div className="divider" style={{ margin: 'var(--space-1) 0' }} />
            <SensorValue label="Soil Temperature" value={summary.soil_temperature_c} unit="°C" />
            <div className="divider" style={{ margin: 'var(--space-1) 0' }} />
            <SensorValue label="Light Intensity" value={summary.light_lux} unit="lux" decimals={0} />
            <div className="divider" style={{ margin: 'var(--space-1) 0' }} />
            <SensorValue label="Leaf Wetness" value={summary.leaf_wetness_pct} unit="%" />
            <div className="divider" style={{ margin: 'var(--space-1) 0' }} />
            <SensorValue
              label="Water Availability"
              value={summary.water_level_available}
              status={summary.water_level_available === false ? 'critical' : 'normal'}
            />
          </div>
          {summary.last_updated && (
            <div style={{ color: 'var(--color-text-muted)', fontSize: 'var(--text-xs)', marginTop: 'var(--space-2)', paddingLeft: 'var(--space-1)' }}>
              Last reading: {formatDistanceToNow(new Date(summary.last_updated))} ago
            </div>
          )}
        </div>
      </div>

      {/* ── Scenario control (demo panel) ────────────────────── */}
      <ScenarioControl />
    </div>
  );
}

function ScenarioControl() {
  const [active, setActive] = useState('NORMAL');
  const [changing, setChanging] = useState(false);
  const queryClient = useQueryClient();

  const SCENARIOS = [
    { id: 'NORMAL', label: 'Normal' },
    { id: 'WATER_STRESS', label: 'Water Stress' },
    { id: 'HEAT_STRESS', label: 'Heat Stress' },
    { id: 'EXCESS_MOISTURE', label: 'Excess Moisture' },
    { id: 'LOW_WATER', label: 'Low Water' },
    { id: 'ACTIVITY_EVENT', label: 'Activity Event' },
  ];

  const apply = async (scenario: string) => {
    setChanging(true);
    await api.simulator.setScenario(scenario);
    setActive(scenario);
    setChanging(false);
    setTimeout(() => {
      queryClient.invalidateQueries({ queryKey: ['field-condition'] });
    }, 12000); // Wait for next reading
  };

  return (
    <div className="card" style={{ borderColor: 'var(--color-status-info-border)', background: 'var(--color-status-info-bg)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', marginBottom: 'var(--space-3)' }}>
        <span style={{ color: 'var(--color-status-info)', fontSize: 'var(--text-xs)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          DEMO — SIMULATION CONTROL
        </span>
      </div>
      <p style={{ color: 'var(--color-text-muted)', fontSize: 'var(--text-xs)', marginBottom: 'var(--space-3)' }}>
        Switch scenarios to test the decision engine. Changes take effect on the next sensor reading (~10s).
        The frontend has no knowledge of the scenario — only raw sensor values flow through.
      </p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--space-2)' }}>
        {SCENARIOS.map(s => (
          <button
            key={s.id}
            className={`btn ${active === s.id ? 'btn-primary' : 'btn-secondary'} btn-sm`}
            onClick={() => apply(s.id)}
            disabled={changing}
          >
            {s.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-6)' }}>
      <div className="skeleton" style={{ height: 40, width: '40%' }} />
      <div className="skeleton" style={{ height: 100 }} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--space-4)' }}>
        {[...Array(4)].map((_, i) => <div key={i} className="skeleton" style={{ height: 80 }} />)}
      </div>
    </div>
  );
}

function ErrorState({ message }: { message: string }) {
  return (
    <div className="alert-banner alert-banner-critical" style={{ maxWidth: 500 }}>
      <span>⚠</span>
      <div>
        <div style={{ fontWeight: 600, marginBottom: 4 }}>Connection Error</div>
        <div style={{ fontSize: 'var(--text-sm)', color: 'var(--color-text-secondary)' }}>{message}</div>
      </div>
    </div>
  );
}
